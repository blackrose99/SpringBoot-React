package com.proyectomomgo1.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoMongo1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoMongo1Application.class, args);
	}

}
